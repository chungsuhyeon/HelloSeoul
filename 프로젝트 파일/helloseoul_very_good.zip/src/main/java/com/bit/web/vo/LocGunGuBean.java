package com.bit.web.vo;

import lombok.Data;

@Data
public class LocGunGuBean {
	private String kr_gu;
	private String en_gu;

}
