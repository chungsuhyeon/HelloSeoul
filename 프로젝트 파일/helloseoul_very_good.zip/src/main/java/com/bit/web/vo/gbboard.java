package com.bit.web.vo;

import lombok.Data;

@Data
public class gbboard {
	private int com_no;
	private String user_id;
	private int good;
	private int bad;
}
