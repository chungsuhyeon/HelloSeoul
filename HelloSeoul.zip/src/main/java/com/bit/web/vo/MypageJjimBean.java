package com.bit.web.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MypageJjimBean {
	private String user_id;
	private int loc_pc;
	private String loc_name;
	private String loc_ctg1;
	private String loc_ctg2;
	private String loc_sg;
}
