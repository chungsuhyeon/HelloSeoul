package com.bit.web.vo;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MypageMainPlannerList {
	private List<MypageMainPlannerBean> mainPlannerList;
}
