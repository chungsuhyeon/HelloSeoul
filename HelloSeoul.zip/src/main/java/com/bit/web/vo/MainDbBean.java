package com.bit.web.vo;

import lombok.Data;

@Data
public class MainDbBean {
	private int loc_pc;
	private String loc_name;
	private String loc_ctg1;
	private String loc_ctg2;
	private String loc_sg;
	private String loc_addr;
	private String loc_time;
	private String loc_tel;
	private String loc_info;
	private String loc_img;
	private float loc_x;
	private float loc_y;
	private String loc_tag;

}
