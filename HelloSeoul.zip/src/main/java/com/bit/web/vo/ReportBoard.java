package com.bit.web.vo;

import lombok.Data;

@Data
public class ReportBoard {
	int com_no;
	int report_reason;
	String user_id;
}
