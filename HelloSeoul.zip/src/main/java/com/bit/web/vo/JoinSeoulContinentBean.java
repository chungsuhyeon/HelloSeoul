package com.bit.web.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class JoinSeoulContinentBean {
	private String country_name;
	private int country_no;
	private String continent;
	
}
