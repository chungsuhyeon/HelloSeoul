package com.bit.web.vo;

import lombok.Data;

@Data
public class CurPageBlockBean {
	private int curPage;
	private int curBlock;

}
