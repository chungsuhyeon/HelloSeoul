package com.bit.web.vo;

import lombok.Data;

@Data
public class SeatBoard {
	private int no;
	private String user_id;
	private String seat;
	private String rundate;
}
